create
    definer = employees@`%` procedure GetSalarySum()
BEGIN
    SELECT
        SUM(amount)
    FROM
        salary;
END;

